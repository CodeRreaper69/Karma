import curses
import time
import os
#import hashlib





    
def show_help(stdscr):
    stdscr.clear()
    display_commands(stdscr)
    stdscr.refresh()
    time.sleep(20)

# Function to display commands
def display_commands(stdscr):
    stdscr.addstr("--------------------------------------------------\n")
    stdscr.addstr("                       COMMANDS                      \n")
    stdscr.addstr("                  read for 20 seconds                      \n")
    stdscr.addstr("--------------------------------------------------\n\n")
    stdscr.addstr("  show <text>       - Displays text\n")
    stdscr.addstr("    Example: show Hello, world!\n\n")
    stdscr.addstr("  shut / poweroff / turnoff      - shutdown screen and system after 2 mins\n")
    stdscr.addstr("  off                            - poweroff screen and system immediately\n")
    stdscr.addstr("  cancel/no_shut                 - cancel the turning off\n")
    stdscr.addstr("  hi / info / who/ what / whoareyou / tellmeaboutyou / - information about the OS \n")
    stdscr.addstr("  history           - Displays command history\n")
    stdscr.addstr("    Example: history\n\n")
    stdscr.addstr("  create <filename> - Creates a new file\n")
    stdscr.addstr("    Example: create newfile.txt\n\n")
    stdscr.addstr("  files             - Shows files in the current directory\n")
    stdscr.addstr("    Example: files\n\n")
    stdscr.addstr("  find <filename>   - Finds a file\n")
    stdscr.addstr("    Example: find myfile.txt\n\n")
    stdscr.addstr("  areyouthere       - Displays user info\n")
    stdscr.addstr("    Example: areyouthere\n\n")
    stdscr.addstr("  whoami            - Displays current user\n")
    stdscr.addstr("    Example: whoami\n\n")
    stdscr.addstr("  exit / q / quit             - Quits the terminal\n")
    stdscr.addstr("    Example: exit\n")
    stdscr.addstr("\n--------------------------------------------------\n")
    #stdscr.refresh()
    #time.sleep(10)

#intro of this terminal 
def intro(stdscr):
    stdscr.clear()
    stdscr.addstr("--------------------------------------------------\n")
    stdscr.addstr("                  WELCOME TO KARMA OS              \n")
    stdscr.addstr("                  read for 15 seconds                      \n")
    stdscr.addstr("--------------------------------------------------\n\n")
    stdscr.addstr("Karma OS is a minimalistic terminal designed for\n")
    stdscr.addstr("security purposes, providing a distraction-free\n")
    stdscr.addstr("environment for everyday tasks. It prioritizes\n")
    stdscr.addstr("control and security, offering a command-line\n")
    stdscr.addstr("interface without any graphical distractions.\n\n")
    stdscr.addstr("This terminal allows for precise control over the\n")
    stdscr.addstr("target user, ensuring a high level of security.\n\n")
    stdscr.addstr("To get started, explore the commands and features\n")
    stdscr.addstr("available. Use 'help' for a list of documented\n")
    stdscr.addstr("commands.\n\n")
    stdscr.addstr("Feel free to ask for assistance or use the\n")
    stdscr.addstr("commands to streamline your tasks.\n\n")
    stdscr.addstr("Enjoy your secure and minimalist computing\n")
    stdscr.addstr("experience with Karma OS!\n")
    stdscr.addstr("--------------------------------------------------\n")
    stdscr.refresh()
    time.sleep(15)


# USER AUTHENTICATION
def users(name, passwd, stdscr): #stdscr):
    users = ["SOURABH", "SOURAV", "IEM", "SHRAMAN"]
    auth = {"SOURABH": "123", "SOURAV": "456", "IEM": "789", "SHRAMAN": "012"}

    if name in users and passwd in auth[name]:
        stdscr.addstr("WELCOME")#stdscr
        time.sleep(5)
        return True
    else:
        stdscr.addstr("WRONG USERNAME OR PASSWORD")#stdscr
        time.sleep(3)
        return False

# Function to display text with a delay
def show_with_delay(window, text, delay=0.1):
    for char in text:
        window.addch(char)
        window.refresh()
        time.sleep(delay)

# Function to display history
def display_history(window, history):
    window.addstr("History:\n")
    for action in history:
        window.addstr("- " + action + "\n")
    window.refresh()

# Function to create a file
def create_file(name):
    with open(name, 'w') as file:
        file.write("")

# Function to display all files in the folder
def display_files(window):
    files = os.listdir()
    window.addstr("Files:\n")
    for file in files:
        window.addstr("- " + file + "\n")
    window.refresh()

# Function to find a file
def find_file(window, name):
    files = os.listdir()
    found = False
    for file in files:
        if name in file:
            window.addstr("Found: " + file + "\n")
            found = True
    if not found:
        window.addstr("No file found with that name.\n")
    window.refresh()



def shut(stdscr):
    os.system("shutdown -h 2")
def off(stdscr):
    os.system("poweroff")
def cancel(stdscr):
    os.system("shutdown -c")

# Function to check user's active status
def are_you_there(window, username):
    window.clear()
    window.addstr("Active Status: " + username + "\n")
    window.refresh()


# Function to initialize the terminal interface
def init_terminal(stdscr):
    # Set up colors if supported
    curses.start_color()
    curses.use_default_colors()

    # Set up color pair for text
    curses.init_pair(1, curses.COLOR_WHITE, -1)

    # Set up window
    stdscr.clear()
    stdscr.refresh()

    # Welcome message with delay
    show_with_delay(stdscr, "WELCOME TO KHUDKHUSI TERMINAL (type help for listed commands after successful login)\n", 0.1)
    time.sleep(1)

    # Small screen to enter username
    while True:
        stdscr.clear()
        stdscr.addstr("Enter username: ")
        curses.echo()
        username = stdscr.getstr().decode('utf-8')
        stdscr.addstr("Enter password: ")
        password = stdscr.getstr().decode('utf-8')
        if users(username, password, stdscr):
            break

    curses.noecho()

    # Toggle full-screen mode with Fn + F11
    #toggle_full_screen(stdscr)

    history = []
    while True:
        # Full-screen mode with no border look
        curses.curs_set(2)#blinking cursor
        stdscr.clear()
        stdscr.border(0)
        stdscr.refresh()

        # Command loop
        curses.echo()
        stdscr.addstr(1, 1, "KARMA->> ")
        cmd = stdscr.getstr().decode('utf-8')
        history.append(cmd)

        if cmd.startswith("show "):
            text = cmd.split(" ", 1)[1]
            show_with_delay(stdscr, text + "\n")

        elif cmd == "history":
            display_history(stdscr, history)

        elif cmd.startswith("create "):
            filename = cmd.split(" ", 1)[1]
            create_file(filename)

        elif cmd == "files":
            display_files(stdscr)
            time.sleep(2)

        elif cmd.startswith("find "):
            filename = cmd.split(" ", 1)[1]
            find_file(stdscr, filename)

        elif cmd in ["areyouthere", "whoami", "me"]:
            are_you_there(stdscr, username)

        elif cmd in ["exit", "q", "quit"]:
            exit()

        elif cmd.lower() in ["shut","shutdown","poweroff","turnoff"]:
            shut(stdscr)
        elif cmd.lower() in ["shut","shutdown","poweroff","turnoff"]:
            off(stdscr)
        elif cmd.lower() in ["cancel","no_shut"]:
            cancel(stdscr)
        

        

        # Inside the main loop
        elif cmd.lower() in ["hi", "hello", "whoareyou", "what", "tellmeaboutyou","info"]:
            intro(stdscr)
        elif cmd.startswith("help") or cmd.startswith("how"): # in ["help", "?", "how", "who"]:
            show_help(stdscr)
            #time.sleep(20)
        #cmd.startswith("help") or cmd.startswith("?") or cmd.startswith("!"):
            #display_commands(stdscr)
            #show_help(stdscr)
            #stdscr.refresh()
            #time.sleep(10)
            
            #intro2(stdscr)
            #time.sleep(20)
            


        else:
            stdscr.addstr("COMMAND NOT FOUND\n")

        time.sleep(1)

    # Cleanup
    curses.endwin()
    
def karma():
    author = "\033[1;35mKhudKhushi.co\033[0m"  # Magenta color
    email = "\033[1;36mkhud.khushi@gmail.com\033[0m"  # Cyan color
    print("\033[1;33mWELCOME TO!\033[0m")
    print("\033[1;33m                                                                                                                                     \033[0m")
    print("\033[1;33m                                                                                                                                     \033[0m")
    time.sleep(0.3)
    print("\033[1;36m  o         o/          o           o__ __o         o          o           o                   o__ __o          o__ __o    \033[0m")
    print("\033[1;36m <|>       /v          <|>         <|     v\       <|\        /|>         <|>                 /v     v\        /v     v\   \033[0m")
    time.sleep(0.3)
    print("\033[1;36m / >      />           / \         / \     <\      / \\o    o// \         / \                />       <\      />       <\  \033[0m")
    print("\033[1;36m \o__ __o/           o/   \o       \o/     o/      \o/ v\  /v \o/       o/   \o            o/           \o   _\o____       \033[0m")
    time.sleep(0.3)
    print("\033[1;36m  |__ __|           <|__ __|>       |__  _<|        |   <\/>   |       <|__ __|>          <|             |>       \_\__o__ \033[0m")
    print("\033[1;36m  |      \          /       \       |       \      / \        / \      /       \           \\           //              \  \033[0m")
    time.sleep(0.3)
    print("\033[1;36m <o>      \o      o/         \o    <o>       \o    \o/        \o/    o/         \o           \         /      \         /  \033[0m")
    print("\033[1;36m  |        v\    /v           v\    |         v\    |          |    /v           v\           o       o        o       o   \033[0m")
    print("\033[1;36m / \        <\  />             <\  / \         <\  / \        / \  />             <\          <\__ __/>        <\__ __/>    \033[0m")
    time.sleep(0.3)
    print("\033[1;33m                                                                                                                                     \033[0m")
    print("\033[1;33m                                                                                                                                     \033[0m")
    print("\033[1;33m                                                                                                                                     \033[0m")
    print(f"\n\033[1;35m    Author:\033[0m {author}")  # Magenta color for Author
    print(f"    \033[1;36mEmail:\033[0m {email}")  # Cyan color for Email
    print("    \033[1;33mAbout - Type 'hi' in the khudkhushi command line after login for further details\033[0m")  # Yellow color for About
    print("    \033[1;32mWILL BE STARTING IN A FEW SEC\033[0m")  # Green color for starting message
    
    time.sleep(5)
    curses.wrapper(init_terminal)

    
if __name__ == "__main__":
    karma()
